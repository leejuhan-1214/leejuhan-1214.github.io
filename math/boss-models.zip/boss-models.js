import * as THREE from 'three';
import { createFormulaMesh } from './formula-mesh.js';

// Every visible body/weapon surface is an extruded expression. No armor shells,
// printed decals, sprites, image textures, or ordinary block body geometry.
const UP = new THREE.Vector3(0, 1, 0);
const clamp = THREE.MathUtils.clamp;
function group(parent, name, x=0, y=0, z=0) {
  const g=new THREE.Group();g.name=name;g.position.set(x,y,z);parent.add(g);return g;
}

function writer(model) {
  function text(parent,name,formula,x,y,z,height,color,{depth=.16,glow=.08,width,stroke=.115}={}) {
    const m=createFormulaMesh(formula,{height,depth,stroke,color,emissive:color,emissiveIntensity:glow,metalness:.3,roughness:.48});
    m.name=name;m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;
    if(width) {
      m.geometry.computeBoundingBox();
      const size=m.geometry.boundingBox.max.x-m.geometry.boundingBox.min.x;
      if(size>width)m.scale.x=width/size;
    }
    Object.assign(m.userData,{formula,formulaMesh:true,ink:new THREE.Color(color),elementInk:new THREE.Color(color),inkOpacity:1,mathPart:true,baseGlow:glow});
    model.userData.parts.push(m);parent.add(m);return m;
  }
  function joint(parent,name,formula,from,to,color,width=.28) {
    const a=new THREE.Vector3(...from),delta=new THREE.Vector3(...to).sub(a);
    const m=text(parent,name,formula,...a.addScaledVector(delta,.5).toArray(),delta.length(),color,{width,depth:.2});
    m.quaternion.setFromUnitVectors(UP,delta.normalize());return m;
  }
  return {text,joint};
}

function spear(s,parent,scale=1) {
  const weapon=group(parent,'compass-spear');weapon.scale.setScalar(scale);
  s.text(weapon,'integral-shaft','∫',0,0,0,3.5,'#aacfe3',{width:.22,depth:.2});
  s.text(weapon,'nabla-spearhead','∇',0,1.58,0,1.25,'#b2f0ff',{width:1.15,depth:.22,glow:.28});
  s.text(weapon,'inverse-spearheart','1/x',0,1.55,-.14,.36,'#e7fcff',{width:.68,glow:.45});
  s.text(weapon,'delta-butt','Δ',0,-1.85,0,.38,'#74cbed',{width:.3});
  return weapon;
}
function cleaver(s,parent,scale=1) {
  const weapon=group(parent,'integral-cleaver');weapon.scale.setScalar(scale);
  s.text(weapon,'integral-blade','∫',0,1.2,0,2.9,'#e2b882',{depth:.31,width:1.1,stroke:.18});
  s.text(weapon,'burning-derivative','dx',.06,-.18,-.02,.46,'#ffae55',{width:.52,glow:.35});
  s.text(weapon,'integral-handle','x',0,-.62,0,.5,'#b99b77',{width:.3,depth:.22});
  return weapon;
}
function thunderBlade(s,parent,scale=1) {
  const weapon=group(parent,'vector-blade');weapon.scale.setScalar(scale);
  s.text(weapon,'radical-blade','√',0,.78,0,1.95,'#f5d473',{width:.82,depth:.2,stroke:.16,glow:.2});
  s.text(weapon,'delta-guard','Δ',0,-.16,0,.46,'#e6debc',{width:.42});
  return weapon;
}
function cannon(s,parent,scale=1) {
  const weapon=group(parent,'sigma-cannon');weapon.scale.setScalar(scale);
  for(const z of [-.2,-.64,-1.08])s.text(weapon,'sigma-barrel','Σ',0,0,z,.84,'#cfdfc9',{depth:.24,width:.72,glow:.08});
  s.text(weapon,'cannon-function','f(x)',0,.12,-1.25,.3,'#89f3c8',{depth:.1,width:.62,glow:.5});
  return weapon;
}

function glacier(model,rig,s) {
  const data=model.userData,ice='#87d6f3',silver='#cee4ee';
  const torso=group(rig,'glacier-torso',0,2.9,0);
  s.text(torso,'nabla-ribcage','∇',0,.05,-.05,1.65,silver,{width:1.35,depth:.33});
  const heart=s.text(torso,'reciprocal-heart','f(x)=1/x',0,.12,-.3,.44,ice,{width:1.52,depth:.13,glow:.38});data.core=heart;data.bossWeakCore=heart;
  s.text(torso,'inverse-spine','x^-1',0,-.45,.3,.65,silver,{width:1.2,depth:.24});
  for(const side of [-1,1]) {
    const sideBody=s.text(torso,'reciprocal-flank','(x)',side*.46,0,.12,.9,ice,{width:.65,depth:.15});sideBody.rotation.y=side*Math.PI/2;
    const arm=group(torso,'glacier-arm',side*.81,.5,0);data.bossArms.push(arm);
    s.text(arm,'delta-shoulder','Δ',0,0,0,.61,silver,{width:.65,depth:.24});
    s.joint(arm,'integral-upper-arm','∫',[0,-.15,0],[side*.12,-.79,0],ice,.2);
    s.joint(arm,'radical-forearm','√',[side*.12,-.79,0],[side*.08,-1.42,-.1],silver,.32);
    s.text(arm,'differential-hand','dx',side*.08,-1.48,-.1,.32,ice,{width:.38});
    for(const z of [-.1,.35])s.text(rig,'inverse-leg','∫',side*.39,.99,z,1.35,silver,{width:.3,depth:.18});
    const shard=group(rig,'orbit-ice',side*1.38,3.85,.52);data.bossSatellites.push(shard);
    s.text(shard,'nabla-ice','∇',0,0,0,.78,ice,{width:.42,depth:.28,glow:.28});
    s.text(shard,'inverse-ice','x^-1',0,-.43,0,.25,silver,{width:.55});
  }
  s.text(rig,'nabla-head','∇',0,4.08,-.05,.75,silver,{width:.62,depth:.35});
  s.text(rig,'ice-face','1/x',0,4.02,-.27,.26,ice,{width:.43,depth:.1,glow:.5});
  s.text(rig,'ice-crown','Δ',0,4.64,.07,.33,ice,{width:.3,depth:.16});
  const weapon=spear(s,data.bossArms[0],.88);weapon.position.set(-.22,-.92,-.2);data.bossWeapon=weapon;
}

function furnace(model,rig,s) {
  const data=model.userData,ivory='#e5cba7',amber='#f0a65b',hot='#ffd17b';
  const torso=group(rig,'furnace-torso',0,2.3,0);data.bossTorso=torso;
  s.text(torso,'summation-chest','Σ',0,.66,0,1.35,ivory,{width:1.95,depth:.48,stroke:.17});
  s.text(torso,'integral-abdomen','∫f(x)dx',0,-.7,0,.66,ivory,{width:2.2,depth:.34,stroke:.12});
  for(const side of [-1,1]) {
    const flank=s.text(torso,'furnace-flank','Σ',side*.91,0,.18,1.35,amber,{width:1,depth:.3});flank.rotation.y=side*Math.PI/2;
    s.text(torso,'furnace-back','∫',side*.48,0,.65,1.86,ivory,{width:.53,depth:.3});
    const leg=group(rig,'furnace-leg',side*.67,1.22,.08);data.bossLegs.push(leg);
    s.text(leg,'sum-shin','Σ',0,-.43,0,1.02,ivory,{width:.64,depth:.4,stroke:.16});
    s.text(leg,'radical-foot','√',0,-.97,-.17,.44,amber,{width:.73,depth:.48,stroke:.18});
    const arm=group(torso,'furnace-arm',side*1.1,.62,0);data.bossArms.push(arm);
    s.text(arm,'sigma-shoulder','Σ',0,0,0,.77,ivory,{width:.77,depth:.45,stroke:.17});
    s.text(arm,'heavy-integral-arm','∫',side*.13,-.62,0,1.08,amber,{width:.44,depth:.32,stroke:.16});
    s.text(arm,'integral-gauntlet','∂',side*.22,-1.25,-.05,.58,ivory,{width:.5,depth:.4});
    s.text(torso,'integral-exhaust','∫',side*.63,1.41,.45,.97,amber,{width:.35,depth:.25});
  }
  const mouth=s.text(torso,'open-function-mouth','()',0,-.05,-.62,1.31,ivory,{width:1.38,depth:.25,stroke:.17});data.bossFurnaceRing=mouth;
  const core=s.text(torso,'glowing-integral-core','∫',0,-.05,-.67,.78,hot,{width:.55,depth:.2,glow:.8});data.bossWeakCore=core;data.core=core;
  data.bossGrates=[];
  for(const x of [-.36,0,.36]) {
    const grate=s.text(torso,'equality-gate','=',x,-.05,-.87,.28,amber,{width:.95,depth:.18,stroke:.18});grate.rotation.z=Math.PI/2;data.bossGrates.push(grate);
  }
  s.text(torso,'integral-head','∫',0,1.35,-.15,.68,ivory,{width:.55,depth:.3});
  s.text(torso,'equality-eyes','=',0,1.32,-.35,.21,hot,{width:.36,depth:.08,glow:.5});
  const weapon=cleaver(s,data.bossArms[1],.9);weapon.position.set(.25,-1.18,-.28);weapon.rotation.z=-.19;data.bossWeapon=weapon;
}

function thunder(model,rig,s) {
  const data=model.userData,gold='#edd17a',ivory='#e7ead2',gray='#9ba6b4';
  const torso=group(rig,'thunder-torso',0,2.35,0);
  s.text(torso,'delta-thorax','Δ',0,0,0,1.25,ivory,{width:1.08,depth:.34,stroke:.13});
  const heart=s.text(torso,'limit-heart','lim(x)',0,.17,-.23,.38,gold,{width:1.23,depth:.14,glow:.3});data.core=heart;data.bossWeakCore=heart;
  const spine=s.text(torso,'limit-spine','lim(x)',0,-.07,.25,.49,gray,{width:1.15,depth:.16});spine.rotation.z=Math.PI/2;
  for(const side of [-1,1]) {
    const leg=group(rig,'mantis-leg',side*.49,1.74,.18);data.bossLegs.push(leg);
    s.joint(leg,'radical-thigh','√',[0,0,0],[side*.22,-.72,.4],ivory,.34);
    s.text(leg,'delta-knee','Δ',side*.22,-.72,.4,.35,gold,{width:.3,depth:.22});
    s.joint(leg,'radical-shin','√',[side*.22,-.72,.4],[side*.46,-1.42,-.22],gold,.29);
    s.text(leg,'delta-claw','Δ',side*.49,-1.55,-.36,.3,gold,{width:.43,depth:.37});
    const arm=group(torso,'mantis-arm',side*.65,.4,0);data.bossArms.push(arm);
    s.text(arm,'delta-shoulder','Δ',side*.06,.11,.04,.59,ivory,{width:.61,depth:.25});
    s.joint(arm,'radical-upper-arm','√',[0,-.13,0],[side*.32,-.6,.07],gray,.22);
    s.joint(arm,'derivative-forearm','∂',[side*.32,-.6,.07],[side*.25,-1.03,-.45],gold,.3);
    const weapon=thunderBlade(s,arm,.8);weapon.position.set(side*.28,-1.12,-.45);weapon.rotation.x=-1.2;weapon.rotation.z=-side*.4;if(side<0)data.bossWeapon=weapon;
  }
  s.text(torso,'triangular-head','Δ',0,1.03,-.16,.73,ivory,{width:.83,depth:.37,stroke:.15});
  s.text(torso,'limit-face','lim',0,.97,-.38,.24,gold,{width:.52,depth:.09,glow:.45});
  const tail=group(torso,'lightning-tail',0,.2,.45);data.bossTail=tail;
  const joints=[[0,0,0],[0,.55,.7],[0,1.36,.95],[0,2.04,.48],[0,2.46,-.18],[0,2.5,-.92],[0,2.12,-1.43]];
  for(let i=1;i<joints.length;i++)s.joint(tail,'formula-tail-link',i%2?'Δ':'+',joints[i-1],joints[i],i%2?gold:ivory,.3);
  s.text(tail,'lightning-sting','√',0,1.97,-1.56,.47,gold,{width:.35,depth:.2,glow:.5});
}

function storm(model,rig,s) {
  const data=model.userData,ivory='#d9f0df',green='#88e7c6',teal='#89bfb9';
  const body=group(rig,'manta-body',0,2.65,0);data.bossTorso=body;
  s.text(body,'sigma-fuselage','Σ',0,0,0,1.1,ivory,{width:.92,depth:.58,stroke:.16});
  s.text(body,'sin-spine','sin(x)',0,.33,.17,.41,teal,{width:1.42,depth:.2}).rotation.y=Math.PI/2;
  data.bossTurbines=[];data.bossWings=[];
  for(const side of [-1,1]) {
    const wing=group(body,'function-wing',side*.45,0,.12);data.bossWings.push(wing);wing.userData.side=side;
    const upper=s.text(wing,'function-wing-span',side<0?'sin(x)':'cos(x)',side*1.05,.21,0,.61,ivory,{width:2.5,depth:.22,stroke:.13});upper.rotation.z=side*.14;
    const lower=s.text(wing,'function-wing-branch',side<0?'sin(x)':'cos(x)',side*.91,-.25,.31,.46,teal,{width:2.1,depth:.18});lower.rotation.z=-side*.11;
    s.text(wing,'sum-wingtip','Σ',side*2.14,.05,.03,.44,green,{width:.45,depth:.24});
    for(const z of [-.72,.78]) {
      const turbine=group(wing,'formula-turbine',side*1.15,.08,z);data.bossTurbines.push(turbine);
      s.text(turbine,'zero-turbine-rim','0',0,0,0,1.05,teal,{width:1.05,depth:.17,stroke:.13}).rotation.x=-Math.PI/2;
      const rotor=group(turbine,'rotor');turbine.userData.rotor=rotor;
      s.text(rotor,'sum-rotor','+',0,.08,0,.79,green,{width:.79,depth:.1,glow:.2}).rotation.x=-Math.PI/2;
    }
  }
  const tail=s.text(body,'tail-integral','∫',0,.03,1.2,1.08,teal,{width:.34,depth:.22});tail.rotation.x=Math.PI/2;
  const core=s.text(body,'rear-propulsion-equation','f(x)',0,.2,1.68,.55,green,{width:1.04,depth:.25,glow:.55});core.rotation.y=Math.PI;data.bossWeakCore=core;data.core=core;
  const gun=cannon(s,body,1);gun.position.set(0,-.51,-.5);data.bossWeapon=gun;
  const fin=s.text(body,'dorsal-sigma','Σ',0,.55,.33,.76,ivory,{width:.59,depth:.25});fin.rotation.y=Math.PI/2;
}

function sovereign(model,rig,s) {
  const data=model.userData,ivory='#eadff4',gold='#dfc480';
  const center=group(rig,'orrery-core',0,2.63,0);data.bossTorso=center;
  const core=s.text(center,'composition-core','f(g(x))',0,0,-.18,.8,'#c7a1fc',{width:2.05,depth:.38,glow:.55});data.bossWeakCore=core;data.core=core;
  s.text(center,'omega-core-frame','Ω',0,0,.12,1.84,ivory,{width:1.72,depth:.4,stroke:.14});
  for(const side of [-1,1]) {
    const flank=s.text(center,'nested-function-flank','f(g(x))',side*.63,0,.2,.58,ivory,{width:1.48,depth:.2});flank.rotation.y=side*Math.PI/2;
    s.text(center,'composition-crown','∂',side*.37,.99,.12,.44,gold,{width:.4,depth:.2});
  }
  data.bossOrbits=[];
  const colors=['#9cdcf3','#f6bb81','#efdc8e','#9ee4c5'];
  const equations=['1/x','∫f(x)dx','lim(x)','sin(x)'];
  const builders=[spear,cleaver,thunderBlade,cannon];
  for(let i=0;i<4;i++) {
    const axis=group(center,'formula-orbit-'+i);data.bossOrbits.push(axis);axis.userData.tilt=i*Math.PI/4;axis.rotation.z=axis.userData.tilt;
    for(let j=0;j<6;j++) {
      const angle=j/6*Math.PI*2,radius=1.75+i*.075;
      const phrase=s.text(axis,'equation-orbit-segment',equations[i],Math.sin(angle)*radius,0,Math.cos(angle)*radius,.28,colors[i],{width:1.5,depth:.13,stroke:.12});phrase.rotation.y=angle+Math.PI;
    }
    const mount=group(axis,'orbit-weapon',Math.cos(i*Math.PI/2)*2,0,Math.sin(i*Math.PI/2)*2);
    s.text(mount,'element-bearing','∂',0,0,0,.38,colors[i],{width:.35,depth:.25,glow:.24});
    const weapon=builders[i](s,mount,i===3?.59:.5);weapon.rotation.z=i===1?-.65:i===0?.65:0;if(i===2)weapon.rotation.x=-Math.PI/2;axis.userData.weapon=mount;
  }
  const crown=group(rig,'omega-crown',0,4.48,0);data.bossCrown=crown;
  s.text(crown,'omega-crown-letter','Ω',0,0,0,.87,gold,{width:1,depth:.23,stroke:.15});
  s.text(rig,'crown-limit-base','lim(x)',0,4.05,0,.28,ivory,{width:1.2,depth:.18});
  s.text(rig,'orrery-keel','∫',0,.72,0,1.1,gold,{width:.3,depth:.25});
}

const BUILDERS={iris:glacier,ram:furnace,mirror:thunder,duality:storm,crown:sovereign};
export function buildBossModel(model,rig,kind) {
  const data=model.userData;data.limbs={};data.bossArms=[];data.bossLegs=[];data.bossSatellites=[];data.bossAssetVersion=3;
  BUILDERS[kind](model,rig,writer(model));
}

export function animateBossModel(model, state, time) {
  const data=model.userData, rig=data.rig;
  const active=state.attackPhase==='active', warning=state.attackPhase==='telegraph';
  const strike=clamp(state.attack||0,0,1), weak=state.weakLeft>0;
  const phase=data.phase||0, moving=Boolean(state.moving), kind=data.bossKind;
  rig.rotation.set(0,0,0);rig.scale.setScalar(1);
  rig.position.y=Math.sin(time*1.7+phase)*(kind==='ram'?.018:.06);
  for(const [i,leg] of data.bossLegs.entries())leg.rotation.x=moving?Math.sin(time*7+i*Math.PI)*.18:0;
  for(const [i,arm] of data.bossArms.entries()) {
    arm.rotation.set(0,0,Math.sin(time*1.9+i)*.025);
  }
  const action=state.attackKind||'';
  if(kind==='iris') {
    const arm=data.bossArms[0];
    const thrust=action.includes('spear')||action.includes('thrust');
    arm.rotation.x=thrust?(warning?-.55*strike:active?-1.42:0):-.08;
    arm.rotation.z=thrust&&active?.25:0;
    data.bossWeapon.rotation.x=thrust?(active?-.15:warning?.35:0):0;
    for(const [i,shard]of data.bossSatellites.entries()) {
      shard.position.y=3.85+Math.sin(time*2+i*Math.PI)*.2;
      shard.rotation.y=time*.7+i;shard.rotation.z=Math.sin(time+i)*.15;
      shard.scale.setScalar(warning&&!thrust?1+strike*.23:1);
    }
  } else if(kind==='ram') {
    const absorb=action.includes('absorb')||action.includes('inhale');
    const arm=data.bossArms[1];
    arm.rotation.z=absorb?-.2:warning?-.85*strike:active?1.15*Math.sin(time*8):0;
    arm.rotation.x=absorb?-.12:warning?-.5:active?-.72:0;
    data.bossWeapon.rotation.z=-.19;
    data.bossFurnaceRing.scale.setScalar(absorb?1+.12*Math.sin(time*10):1);
    for(const [i,grate]of data.bossGrates.entries())grate.position.x=(i-1)*(absorb?.61:.36);
    if(state.crouching) {rig.scale.y=.7;rig.position.y=.05;}
  } else if(kind==='mirror') {
    const dash=active&&(action.includes('dash')||action.includes('charge'));
    rig.rotation.x=dash?-.2:0;rig.position.y-=warning?.18*strike:0;
    data.bossTail.rotation.z=Math.sin(time*(active?5:1.8))*.16;
    data.bossTail.rotation.x=warning?-.16*strike:0;
    for(const [i,arm]of data.bossArms.entries()) {
      arm.rotation.x=active?-.65:warning?.25:0;
      arm.rotation.z=(i?1:-1)*(warning?.3:active?.65:.05);
    }
  } else if(kind==='duality') {
    rig.position.y=.08+Math.sin(time*1.8)*.12;
    for(const turbine of data.bossTurbines)turbine.userData.rotor.rotation.y=time*(active?22:12);
    for(const wing of data.bossWings)wing.rotation.z=wing.userData.side*(Math.sin(time*1.4)*.06+(warning?strike*.12:0));
    data.bossWeapon.position.z=-.5+(active?.09*Math.sin(time*28):0);
    data.bossTorso.rotation.z=moving?Math.sin(time*1.5)*.08:0;
  } else if(kind==='crown') {
    data.bossCrown.rotation.y=Math.sin(time*.45)*.15;
    const pair=({ 'orbit-ice-wind':['ice','wind'], 'orbit-fire-thunder':['fire','electric'], 'orbit-tempest':['electric','wind'] })[action]||null;
    for(const [i,orbit]of data.bossOrbits.entries()) {
      orbit.rotation.set(Math.sin(time*.3+i)*.18,time*(weak?.07:active?.6:.22)*(i%2?-1:1)+i*Math.PI/2,orbit.userData.tilt);
      const deployed=(active||warning)&&Boolean(pair?.includes(['ice','fire','electric','wind'][i]));
      orbit.scale.setScalar(weak?.92:deployed?1.13:1);
    }
  }
  if(data.bossWeakCore) {
    const base=data.bossWeakCore.userData.baseGlow;
    data.bossWeakCore.material.emissiveIntensity=base+(weak?.7:warning?.25+Math.sin(time*10)*.1:0);
  }
}
