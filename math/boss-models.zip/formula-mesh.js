import * as THREE from 'three';

// Stroke coordinates are font-independent, in em units. A formula is one solid
// mesh, including its curved strokes; no texture, sprite or facing constraint.
const TAU = Math.PI * 2;
const glyph = (width, ...paths) => ({ width, paths });
const arc = (x, y, rx, ry, start = 0, end = TAU, steps = 12) =>
  Array.from({ length: steps + 1 }, (_, i) => {
    const a = start + (end - start) * i / steps;
    return [x + Math.cos(a) * rx, y + Math.sin(a) * ry];
  });
const cubic = (a, b, c, d, steps = 10) => Array.from({ length: steps + 1 }, (_, i) => {
  const t = i / steps, u = 1 - t;
  return [u*u*u*a[0]+3*u*u*t*b[0]+3*u*t*t*c[0]+t*t*t*d[0],
    u*u*u*a[1]+3*u*u*t*b[1]+3*u*t*t*c[1]+t*t*t*d[1]];
});
const join = (...paths) => paths.flatMap((path, i) => i ? path.slice(1) : path);
const oval = (x = .32, y = .35, rx = .27, ry = .34) => arc(x,y,rx,ry);
const G = {
  ' ': glyph(.36),
  '∇': glyph(.9, [[.04,.98],[.45,.02],[.86,.98],[.04,.98]]),
  'Δ': glyph(.9, [[.04,.02],[.45,.98],[.86,.02],[.04,.02]]),
  'Σ': glyph(.8, [[.75,.98],[.08,.98],[.47,.5],[.08,.02],[.75,.02]], [[.75,.98],[.75,.84]], [[.75,.02],[.75,.16]]),
  '∫': glyph(.53, join(cubic([.05,-.1],[.52,-.35],[.15,1.35],[.51,1.1],14))),
  'Ω': glyph(.95, [[.02,.02],[.29,.02],...arc(.475,.54,.4,.45,Math.PI*1.23,-Math.PI*.23,14),[.66,.02],[.93,.02]]),
  '∂': glyph(.67, join(cubic([.14,.98],[.7,1.2],[.76,.28],[.46,.05],10), cubic([.46,.05],[-.08,-.1],[.02,.68],[.51,.62],8))),
  '√': glyph(.84, [[.02,.36],[.15,.43],[.29,.02],[.48,.97],[.84,.97]]),
  '∞': glyph(1.04, Array.from({length:25},(_,i)=>{const t=i/24*TAU;return [.52+.47*Math.cos(t),.5+.29*Math.sin(2*t)];})),
  'π': glyph(.8, [[.02,.74],[.78,.74]], [[.24,.74],[.2,.02]], join([[.58,.74],[.57,.14]],cubic([.57,.14],[.57,-.02],[.72,-.02],[.77,.08],4))),
  '+': glyph(.7, [[.04,.5],[.66,.5]], [[.35,.82],[.35,.18]]),
  '-': glyph(.65, [[.04,.5],[.61,.5]]),
  '=': glyph(.7, [[.04,.66],[.66,.66]], [[.04,.34],[.66,.34]]),
  '/': glyph(.59, [[.02,-.06],[.57,1.06]]),
  '(': glyph(.33, arc(.43,.5,.36,.61,Math.PI*.68,Math.PI*1.32,9)),
  ')': glyph(.33, arc(-.1,.5,.36,.61,-Math.PI*.32,Math.PI*.32,9)),
  '[': glyph(.3, [[.27,1.07],[.05,1.07],[.05,-.07],[.27,-.07]]),
  ']': glyph(.3, [[.03,1.07],[.25,1.07],[.25,-.07],[.03,-.07]]),
  '|': glyph(.17, [[.085,-.08],[.085,1.08]]),
  '.': glyph(.16, [[.08,.02],[.08,.07]]),
  ',': glyph(.19, [[.13,.08],[.06,-.11]]),
  ':': glyph(.16, [[.08,.2],[.08,.25]], [[.08,.7],[.08,.75]]),
  '^': glyph(.6, [[.04,.58],[.3,.96],[.56,.58]]),
  '<': glyph(.65, [[.59,.85],[.05,.5],[.59,.15]]),
  '>': glyph(.65, [[.06,.85],[.6,.5],[.06,.15]]),
  '→': glyph(1.02, [[.03,.5],[.97,.5]], [[.63,.83],[.97,.5],[.63,.17]]),
  '0': glyph(.66, oval(.33,.5,.27,.48)),
  '1': glyph(.48, [[.07,.8],[.25,.98],[.25,.02]], [[.06,.02],[.44,.02]]),
  '2': glyph(.67, join(cubic([.05,.78],[.13,1.16],[.75,1.02],[.58,.64],8),[[.58,.64],[.06,.03],[.63,.03]])),
  '3': glyph(.66, join(cubic([.06,.89],[.7,1.2],[.79,.5],[.29,.51],8),cubic([.29,.51],[.85,.54],[.68,-.19],[.05,.13],8))),
  '4': glyph(.72, [[.53,.01],[.53,.99],[.05,.31],[.7,.31]]),
  '5': glyph(.67, join([[.62,.98],[.1,.98],[.07,.55]],cubic([.07,.55],[.83,.83],[.88,-.24],[.05,.09],11))),
  '6': glyph(.68, join(cubic([.59,.94],[.07,1.2],[-.16,-.05],[.36,.02],11),cubic([.36,.02],[.86,.07],[.68,.77],[.13,.49],8))),
  '7': glyph(.67, [[.04,.98],[.63,.98],[.21,.02]]),
  '8': glyph(.68, oval(.34,.27,.29,.25), oval(.34,.75,.25,.23)),
  '9': glyph(.68, join(cubic([.08,.06],[.62,-.2],[.84,1.06],[.32,.98],11),cubic([.32,.98],[-.19,.91],[.02,.23],[.56,.51],8))),
  'x': glyph(.64, [[.04,.7],[.6,.02]], [[.04,.02],[.6,.7]]),
  'y': glyph(.64, [[.04,.7],[.32,.05]], [[.61,.7],[.2,-.29],[.05,-.29]]),
  'z': glyph(.62, [[.04,.7],[.58,.7],[.04,.02],[.58,.02]]),
  'f': glyph(.48, join(cubic([.45,.99],[.09,1.13],[.16,.74],[.16,.6],6),[[.16,.6],[.16,-.2]]), [[.02,.67],[.43,.67]]),
  'g': glyph(.65, oval(.31,.38,.26,.31), join([[.58,.69],[.58,-.13]],cubic([.58,-.13],[.6,-.36],[.16,-.35],[.08,-.2],6))),
  's': glyph(.58, join(cubic([.53,.64],[.06,.87],[-.12,.42],[.3,.36],7),cubic([.3,.36],[.79,.29],[.5,-.16],[.03,.07],7))),
  'i': glyph(.19, [[.095,.02],[.095,.69]], [[.095,.93],[.095,.97]]),
  'n': glyph(.64, [[.06,.02],[.06,.7]], join(cubic([.06,.49],[.21,.91],[.6,.76],[.58,.43],7),[[.58,.43],[.58,.02]])),
  'c': glyph(.61, arc(.34,.36,.28,.34,Math.PI*.24,Math.PI*1.76,11)),
  'o': glyph(.64, oval()),
  't': glyph(.47, join([[.17,.94],[.17,.15]],cubic([.17,.15],[.15,-.03],[.37,-.02],[.43,.08],5)), [[.02,.68],[.42,.68]]),
  'a': glyph(.65, oval(.31,.35,.26,.33), [[.58,.7],[.58,.02]]),
  'b': glyph(.65, [[.06,.02],[.06,1.02]], oval(.32,.35,.26,.33)),
  'd': glyph(.65, oval(.32,.35,.26,.33), [[.58,.02],[.58,1.02]]),
  'e': glyph(.63, join([[.05,.36],[.57,.36]],arc(.32,.36,.27,.34,0,Math.PI*1.73,13))),
  'l': glyph(.27, [[.08,1.02],[.08,.04],[.24,.04]]),
  'm': glyph(.99, [[.06,.02],[.06,.7]], join(cubic([.06,.49],[.18,.88],[.51,.77],[.49,.43],7),[[.49,.43],[.49,.02]]), join(cubic([.49,.49],[.61,.88],[.95,.77],[.93,.43],7),[[.93,.43],[.93,.02]])),
  'p': glyph(.65, [[.06,-.3],[.06,.69]], oval(.32,.38,.26,.31)),
  'r': glyph(.48, [[.06,.02],[.06,.7]], cubic([.06,.48],[.18,.84],[.35,.76],[.45,.68],7)),
  'u': glyph(.65, join([[.06,.7],[.06,.25]],cubic([.06,.25],[.04,-.12],[.58,-.08],[.58,.3],8),[[.58,.3],[.58,.7]]), [[.58,.3],[.58,.02]]),
  'v': glyph(.64, [[.04,.7],[.32,.02],[.6,.7]]),
  'w': glyph(.95, [[.04,.7],[.25,.02],[.48,.56],[.7,.02],[.91,.7]]),
  '?': glyph(.61, join(cubic([.03,.8],[.13,1.18],[.82,1.04],[.5,.59],8),[[.5,.59],[.3,.4],[.3,.3]]), [[.3,.04],[.3,.09]]),
};
// Additional characters used by the game's mathematical bodies and weapons.
G['θ']=glyph(.68,oval(.34,.5,.28,.48),[[.08,.5],[.6,.5]]);
G['φ']=glyph(.72,oval(.36,.45,.3,.34),[[.36,-.15],[.36,1.02]]);
G['χ']=glyph(.65,[[.04,.75],[.6,-.18]],[[.04,-.18],[.6,.75]]);
G['Λ']=glyph(.8,[[.04,.02],[.4,.98],[.76,.02]]);
G['Ψ']=glyph(.82,[[.41,.02],[.41,.98]],join([[.06,.97],[.06,.65]],cubic([.06,.65],[.06,.22],[.76,.22],[.76,.65],10),[[.76,.65],[.76,.97]]));
G['λ']=glyph(.65,[[.05,1.02],[.2,1.02],[.59,.02]],[[.36,.64],[.05,.02]]);
G['μ']=glyph(.65,...G.u.paths,[[.06,.25],[.06,-.3]]);
G['τ']=glyph(.64,[[.04,.71],[.6,.71]],[[.32,.71],[.32,.02]]);
G['±']=glyph(.7,...G['+'].paths,[[.04,.02],[.66,.02]]);
G['·']=glyph(.16,[[.08,.47],[.08,.52]]);
for(const [alias,original] of Object.entries({'−':'-','∑':'Σ','∏':'π','×':'x','ⁱ':'i','²':'2','³':'3','⁰':'0','¹':'1','⁴':'4','ⁿ':'n'})) G[alias]=G[original];
const superscript = new Set(['ⁱ','²','³','⁰','¹','⁴','ⁿ']);
export const FORMULA_CHARACTERS = Object.freeze(Object.keys(G));
const cache = new Map();

function pathStrip(points, halfWidth, depth, positions) {
  if(points.length<2)return;
  const closed = Math.hypot(points[0][0]-points.at(-1)[0],points[0][1]-points.at(-1)[1])<1e-6;
  const p=closed?points.slice(0,-1):points, count=p.length;
  if(count<2)return;
  const edges=p.map((point,i)=>{
    const prev=p[i===0?(closed?count-1:0):i-1],next=p[i===count-1?(closed?0:i):i+1];
    let ax=point[0]-prev[0],ay=point[1]-prev[1],bx=next[0]-point[0],by=next[1]-point[1];
    const al=Math.hypot(ax,ay),bl=Math.hypot(bx,by);
    if(al){ax/=al;ay/=al;}else {ax=bx/bl;ay=by/bl;}
    if(bl){bx/=bl;by/=bl;}else {bx=ax;by=ay;}
    let nx=-ay-by,ny=ax+bx,length=Math.hypot(nx,ny);
    if(length<1e-6){nx=-ay;ny=ax;length=1;}
    nx/=length;ny/=length;
    const offset=halfWidth/Math.max(.4,nx*-ay+ny*ax);
    return [[point[0]+nx*offset,point[1]+ny*offset],[point[0]-nx*offset,point[1]-ny*offset]];
  });
  const z=depth/2;
  const triangle=(a,b,c,face=0)=>{
    const ab=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],ac=[c[0]-a[0],c[1]-a[1],c[2]-a[2]];
    const normal=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];
    if(Math.hypot(...normal)<1e-12)return;
    // Tight letter joins may overlap their strip edges; their visible caps
    // still face outward instead of leaving a backface-culled crack.
    if(face&&normal[2]*face<0)positions.push(...a,...c,...b);
    else positions.push(...a,...b,...c);
  };
  const quad=(a,b,c,d,face=0)=>{triangle(a,b,c,face);triangle(a,c,d,face);};
  const at=(edge,side,z)=>[edge[side][0],edge[side][1],z];
  for(let i=0;i<(closed?count:count-1);i++) {
    const a=edges[i],b=edges[(i+1)%count];
    quad(at(a,0,z),at(a,1,z),at(b,1,z),at(b,0,z),1);
    quad(at(a,1,-z),at(a,0,-z),at(b,0,-z),at(b,1,-z),-1);
    quad(at(a,0,-z),at(a,0,z),at(b,0,z),at(b,0,-z));
    quad(at(a,1,z),at(a,1,-z),at(b,1,-z),at(b,1,z));
  }
  if(!closed) {
    const a=edges[0],b=edges.at(-1);
    quad(at(a,1,z),at(a,0,z),at(a,0,-z),at(a,1,-z));
    quad(at(b,0,z),at(b,1,z),at(b,1,-z),at(b,0,-z));
  }
}

/** Cached solid geometry. height is em height; depth is world depth; stroke is
 * an em fraction. X/Y are centered, and the text reads from the -Z side.
 * Shared geometries must not be disposed while other formula meshes use them. */
export function formulaGeometry(text, { height = 1, depth = .12, stroke = .1 } = {}) {
  text=String(text ?? '');
  height=Number.isFinite(height)&&height>0?height:1;
  depth=Number.isFinite(depth)&&depth>0?depth:.12;
  stroke=Number.isFinite(stroke)&&stroke>0?Math.min(stroke,.3):.1;
  const key=JSON.stringify([text,height,depth,stroke]);
  if(cache.has(key))return cache.get(key);
  const positions=[],unsupported=[];let cursor=0;
  for(const char of text) {
    const shape=G[char]??G['?'];
    if(!G[char]&&!unsupported.includes(char))unsupported.push(char);
    const small=superscript.has(char),scale=small?.58:1,raise=small?.62:0;
    for(const path of shape.paths) {
      const points=path.map(([x,y])=>[(cursor+x*scale)*height,(raise+y*scale)*height]);
      pathStrip(points,stroke*height*scale/2,depth,positions);
    }
    cursor+=(shape.width*scale+.17);
  }
  const geometry=new THREE.BufferGeometry();
  // Rotate the whole solid 180 degrees around Y: from -Z, text is readable and
  // winding remains outward-facing, including side and back surfaces.
  for(let i=0;i<positions.length;i+=3){positions[i]*=-1;positions[i+2]*=-1;}
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  if(positions.length) {
    geometry.computeBoundingBox();
    const center=geometry.boundingBox.getCenter(new THREE.Vector3());
    geometry.translate(-center.x,-center.y,0);
    geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();
  } else {
    geometry.setAttribute('normal',new THREE.Float32BufferAttribute([],3));
    geometry.boundingBox=new THREE.Box3(new THREE.Vector3(),new THREE.Vector3());
    geometry.boundingSphere=new THREE.Sphere(new THREE.Vector3(),0);
  }
  geometry.name=`formula:${text}`;
  geometry.userData={formula:text,unsupported,formulaGeometry:true,front:'-Z'};
  // Eviction drops only the cache reference: existing meshes still own the
  // geometry and remain valid. Repeated production formulas share one buffer.
  if(cache.size>=192)cache.delete(cache.keys().next().value);
  cache.set(key,geometry);
  return geometry;
}

export function createFormulaMesh(text, {
  height=1,depth=.12,stroke=.1,color='#d9fbff',emissive=color,
  emissiveIntensity=0,metalness=.35,roughness=.4,
} = {}) {
  const geometry=formulaGeometry(text,{height,depth,stroke});
  const material=new THREE.MeshStandardMaterial({color,emissive,emissiveIntensity,metalness,roughness,flatShading:true});
  const mesh=new THREE.Mesh(geometry,material);
  mesh.name=`formula:${text}`;mesh.castShadow=true;mesh.receiveShadow=true;
  mesh.userData={formula:String(text??''),formulaMesh:true};
  return mesh;
}
